import React from 'react'

const PersonalDetails = () => {
    return (
        <div>PersonalDetails</div>
    )
}

export default PersonalDetails