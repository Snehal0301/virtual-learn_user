import React from 'react'
import './LoginVerfication.css'

const LoginVerfication = () => {
    return (
        <div className='login-verfication'>LoginVerfication</div>
    )
}

export default LoginVerfication